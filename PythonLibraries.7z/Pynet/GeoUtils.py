"""
Utility geometrical transformation functions for writing GHPython scripts
Author: Paul Poinet
"""

import Rhino.Geometry as rg
import networkx as nx
import System
from System import Array, Double
import Pynet
from Pynet import ListUtils
from copy import deepcopy

import clr
clr.AddReference("MIConvexHull")
import MIConvexHull

def ClosestPtOnSurface(Point, MasterSurface):
    """ Find closest point on a surface. """
    PtU = MasterSurface.ClosestPoint(Point)[1]
    PtV = MasterSurface.ClosestPoint(Point)[2]
    MSClosestPt = MasterSurface.Evaluate(PtU, PtV,0)[1]
    return MSClosestPt

def ClosestPtOnSurfaces(Point, MasterSurfaces):
    """ Find closest points on a list of different surfaces. """
    MSCPts = []
    for i in range(len(MasterSurfaces)):
        PtU = MasterSurfaces[i].ClosestPoint(Point)[1]
        PtV = MasterSurfaces[i].ClosestPoint(Point)[2]
        MSClosestPts = MasterSurfaces[i].Evaluate(PtU, PtV,0)[1]
        MSCPts.append(MSClosestPts)
        MSCPts 
    return MSCPts

def ProjectCurvesToSurface(Curves, MasterSurface, bool):
    """ Projects an array of curves on a surface. """
    arr = System.Array.CreateInstance(rg.Curve, len(Curves))
    brep = System.Array.CreateInstance(rg.Brep, 1)
    if bool == True:
        """ Projects with average vector. """

        endPts = []
        for i in range(len(Curves)):
            endPts.append(Curves[i].PointAtNormalizedLength(0.0))
            endPts.append(Curves[i].PointAtNormalizedLength(1.0))    
            arr[i] = Curves[i]
            brep[0] = MasterSurface.ToBrep()
        MSClosestPts = []

        Vecs = []
        for i in range(len(endPts)):
            PtU = MasterSurface.ClosestPoint(endPts[i])[1]
            PtV = MasterSurface.ClosestPoint(endPts[i])[2]
            MSClosestPts = MasterSurface.Evaluate(PtU, PtV,0)[1]
            Vecs.append(rg.Point3d.Subtract(MSClosestPts, endPts[i]))

        AvVec = AverageListVectors(Vecs)
        return rg.Curve.ProjectToBrep(arr, brep, AvVec, 0.1)
    else:
        for i in range(len(Curves)):
            arr[i] = Curves[i]
            brep[0] = MasterSurface.ToBrep()

        return rg.Curve.ProjectToBrep(arr, brep, rg.Vector3d(0,0,-1), 0.1)

def averageVecsToProject(Curves, MasterSurface):
    """ Averages a list of vectors for further projection onto a master surface. """
    AvVecs = []
    listVecs = []
    listParam = []  
    for i in range(len(Curves)):
        listParam.append(Curves[i].DivideByCount(10,True))
        a = []
        listVecs.append(a)
        for j in range(len(listParam)):
            Pts = Curves[i].PointAt(listParam[i][j])
            PtU = MasterSurface.ClosestPoint(Pts)[1]
            PtV = MasterSurface.ClosestPoint(Pts)[2]
            MSClosestPts = MasterSurface.Evaluate(PtU, PtV,0)[1]
            Vecs = rg.Point3d.Subtract(MSClosestPts, Pts)
            a.append(Vecs)
    for i in range(len(listVecs)):
        AvVecs.append(AverageListVectors(listVecs[i]))
    return AvVecs

def ClosestPolylinesToSurface(Curves, MasterSurface, Res):
    """ Finds closest polylines from a curve on a surface. """
    ClosestPolylines = []
    for i in range(len(Curves)):
        PtsPara = rg.Curve.DivideByCount(Curves[i],Res,True)
        a = []
        for j in range(len(PtsPara)):
            Pts = Curves[i].PointAt(PtsPara[j])
            PtsU = MasterSurface.ClosestPoint(Pts)[1]
            PtsV = MasterSurface.ClosestPoint(Pts)[2]
            a.append(MasterSurface.Evaluate(PtsU, PtsV,0)[1])
        #ClosestPolylines.append(rg.Polyline(a))
        ClosestPolylines.append(rg.Curve.CreateInterpolatedCurve(a,3))
    return ClosestPolylines

def createPtCloudFromPoints(Points, T):

    """ Creates a PointCloud from points. Removes duplicated input points.  """

    PointCloudGlobal = rg.PointCloud() # Declare PointCloud.
    for i in range(len(Points)):
        if len(PointCloudGlobal.GetPoints()) == 0:
            PointCloudGlobal.Add(Points[i])
        Dis = rg.Point3d.DistanceTo(PointCloudGlobal.GetPoints()[PointCloudGlobal.ClosestPoint(Points[i])], Points[i])
        if len(PointCloudGlobal.GetPoints()) > 0 and Dis > T:
            PointCloudGlobal.Add(Points[i])

    return PointCloudGlobal

def removeDuplicateLines(Lines, Tol):

    """ Removes similar lines from a list. """

    # Get start, end points and list of all both points on each line.
    stPtOnLine = []  
    enPtOnLine = []
    PointsGlobal = []

    for i in range(len(Lines)):
        stPtOnLine.append(Lines[i].PointAt(0.0))
        enPtOnLine.append(Lines[i].PointAt(1.0))
        PointsGlobal.append(Lines[i].PointAt(0.0))
        PointsGlobal.append(Lines[i].PointAt(1.0))

    # Add all start and end points to the PointCloud.
    PointCloudGlobal = createPtCloudFromPoints(PointsGlobal, Tol)

    # Check the closest start and end points within the PointCloud and retrieve index for duplicate tuples.
    # Inverted tuples are also considered as duplicates.
    Tuples = []
    for i in range(len(stPtOnLine)):
        SortedTuples = [PointCloudGlobal.ClosestPoint(stPtOnLine[i]),PointCloudGlobal.ClosestPoint(enPtOnLine[i])]
        SortedTuples.sort()
        SortedTuples = tuple(SortedTuples)
        Tuples.append(SortedTuples)
    seenTuples = []
    seenTuplesIndex = []
    for i in range(len(Tuples)):
        if Tuples[i] not in seenTuples: 
            seenTuples.append(Tuples[i])
            seenTuplesIndex.append(i)
    
    # Return list of unique lines.
    UniqueLines = []
    for i in seenTuplesIndex:
        UniqueLines.append(Lines[i])
        
    return UniqueLines

def AverageListVectors(Vectors):
    """ Averages a list of vectors. """
    Vx = []
    Vy = []
    Vz = []
    for i in range(len(Vectors)):
        Vx.append(Vectors[i][0])
        Vy.append(Vectors[i][1])
        Vz.append(Vectors[i][2])
    avVx = sum(Vx) / len(Vx)
    avVy = sum(Vy) / len(Vy)
    avVz = sum(Vz) / len(Vz)
    avVector = rg.Vector3d(avVx, avVy, avVz)
    return avVector

def ConvexHull3D(Points):
    """ Creates a 3D Convex Hull using the library MIConvexHull. """
    Ilist = []
    for i in range(len(Points)):
        arr = Array.CreateInstance(Double, 3)
        x = Double(Points[i].X)
        y = Double(Points[i].Y)
        z = Double(Points[i].Z)
        listDoubles = [x,y,z]
        for j in range(len(listDoubles)):
            arr[j] = listDoubles[j]
        Ilist.append(arr)
    CHullMesh = rg.Mesh()
    hull = MIConvexHull.ConvexHull.Create(Ilist)
    count = 0
    for face in hull.Faces:
        for i in range(3):
            CHullMesh.Vertices.Add(rg.Point3d(face.Vertices[i].Position[0], face.Vertices[i].Position[1], face.Vertices[i].Position[2]))
        CHullMesh.Faces.AddFace(count, count+1, count+2)
        count += 3
    CHullMesh.Normals.ComputeNormals()
    return CHullMesh

def GetLargestFilletBetweenTwoCurves(AngleEdges):

    """ Returns the largest fillet possible between two curves. 
    The ends of the curves must meet at the breaking point. """


    Lengths = []
    for i in range(len(AngleEdges)):
        Lengths.append(AngleEdges[i].GetLength())
    SortedAngleEdges = [x for (y,x) in sorted(zip(Lengths,AngleEdges))]

    stPt0 = SortedAngleEdges[0].PointAtStart
    endPt0 = SortedAngleEdges[0].PointAtEnd
    stPt1 = SortedAngleEdges[1].PointAtStart
    endPt1 = SortedAngleEdges[1].PointAtEnd

    # Calculates bisector
    AnglePlanes = rg.Plane(endPt0, stPt0, stPt1)
    Vec1 = rg.Point3d.Subtract(endPt0, stPt0)
    Vec1Reverse = deepcopy(Vec1)
    Vec1Reverse.Reverse()
    Vec2 = rg.Point3d.Subtract(endPt1, stPt1)
    RadEdges = rg.Vector3d.VectorAngle(Vec1, Vec2, AnglePlanes)
    BisectEdges = RadEdges/2
    rot = rg.Transform.Rotation(BisectEdges, AnglePlanes.ZAxis, AnglePlanes.Origin)
    SortedAngleEdgesCopy = deepcopy(SortedAngleEdges)
    SortedAngleEdgesCopy[0].Transform(rot)
    stPt0Rot = SortedAngleEdgesCopy[0].PointAtStart
    endPt0Rot = SortedAngleEdgesCopy[0].PointAtEnd
    BisectVec = rg.Point3d.Subtract(stPt0Rot, endPt0Rot)
    BisectVec.Unitize()
    BisectVecScale = rg.Vector3d.Multiply(4000, BisectVec) #Create pseudo-infinite line
    FARendPt0Rot = deepcopy(endPt0Rot)
    FARendPt0Rot.Transform(rg.Transform.Translation(BisectVecScale))
    Bisector = rg.Line(endPt0Rot, FARendPt0Rot) 
    
    # Generate Center Radius
    AnglePlanes.Translate(Vec1Reverse)
    VecYAxis = AnglePlanes.YAxis
    VecYAxis.Unitize()
    YAxisScaled = rg.Vector3d.Multiply(1000, VecYAxis) #Create pseudo-infinite line
    newStPt0 = deepcopy(stPt0)
    rg.Point3d.Transform(newStPt0, rg.Transform.Translation(YAxisScaled))
    rg.Line(stPt0, newStPt0)
    ParamBisector = rg.Intersect.Intersection.LineLine(rg.Line(stPt0, newStPt0), Bisector)[2]
    centerRadius = Bisector.PointAt(ParamBisector) 

    # Generate closest point on longest segment
    crv = SortedAngleEdges[1].ToNurbsCurve()
    rg.NurbsCurve.Reparameterize(crv, 1)
    enArc = crv.PointAt(crv.ClosestPoint(centerRadius, 1000)[1])
    
    # Create fillet

    ShatteredCrv = SortedAngleEdges[1].Trim(0,crv.ClosestPoint(centerRadius, 1000)[1])
    
    Arc = rg.Arc(stPt0, Vec1, enArc)
    Fillet = rg.Curve.JoinCurves([ShatteredCrv, Arc.ToNurbsCurve()])[0]
    Fillet.Domain = rg.Interval(0,1)

    # Visualize fillet
    vizArc = rg.Arc(stPt0, Vec1Reverse, enArc)
    
    return Fillet, vizArc

def sortsRadialSegmentsAlongCircle(Plane, RadialSegments):
    """ Sorts radial segments along a circle. """
    Circle = rg.Circle(Plane, 1)
    Circle = Circle.ToNurbsCurve()
    Circle.Domain = rg.Interval(0,1)
    Params = []
    for i in range(len(RadialSegments)):
        Params.append(Circle.ClosestPoint(RadialSegments[i].PointAtNormalizedLength(0.5))[1])
    SortedAlongCircle_Keys = Pynet.ListUtils.sortListKeysWithListValues(Params, RadialSegments)[0]
    SortedAlongCircle_Values = Pynet.ListUtils.sortListKeysWithListValues(Params, RadialSegments)[1]
    SortedAlongCircle_Indices = Pynet.ListUtils.sortListKeysWithListValues(Params, RadialSegments)[2]
    return SortedAlongCircle_Keys, SortedAlongCircle_Values, SortedAlongCircle_Indices

def DivideByCount_GetPoints(Curve, n):
    """ Divides a curve by count. Returns an array of points. """
    ListParams = Curve.DivideByCount(n, True)
    ListPts = []
    for i in range(len(ListParams)):
        ListPts.append(Curve.PointAt(ListParams[i]))
    return ListPts

def SweepOneRail_QuadMesh(Sections, Rail,  Subdivision_U, Subdivision_V, GeometryGeneration):

    """ 
    Author: Paul Poinet / 18.08.2016
    Description: SweepOneRail with Quad-Mesh option.
    Inputs:
        List of two sections
        One rail
    Outputs:
        Quad-Mesh (0), Surface (1) and Profile sections (2)
    """
    import Rhino.Geometry as rg
    from copy import deepcopy

    # Check if sections are periodic
    if Sections[0].IsClosed == True and Sections[1].IsClosed == True:
        boolPeriodic = True
    else:
        boolPeriodic = False

    # Reverse rail in order to preserve the right order of the cross sections along the rail.
    DisStart = rg.Point3d.DistanceTo(Rail.PointAtStart, Sections[0].PointAtNormalizedLength(0.5))
    DisEnd = rg.Point3d.DistanceTo(Rail.PointAtEnd, Sections[0].PointAtNormalizedLength(0.5))
    if DisStart < DisEnd:
        pass
    else:
        Rail.Reverse()
    Rail.Domain = rg.Interval(0,1)

    # Creates a series corresponding to the number of interpolated planes.
    Series = []
    for i in range(Subdivision_U):
        Series.append(i)
    remapSeries = []
    for i in range(len(Series)):
        newValues = float(float(Series[i]) / float(Series[-1]))
        remapSeries.append(newValues)

    # Creates perpendicular frames along the curve
    PerpFrames = []
    for t in remapSeries:
        PerpFrames.append(Rail.PerpendicularFrameAt(t)[1])

    # Projects the sections on WorldXY.
    Transformation0 = rg.Transform.PlaneToPlane(PerpFrames[0], rg.Plane.WorldXY)
    Transformation1 = rg.Transform.PlaneToPlane(PerpFrames[-1], rg.Plane.WorldXY)
    Section0 = deepcopy(Sections[0])
    Section1 = deepcopy(Sections[1])
    Section0.Transform(Transformation0)
    Section1.Transform(Transformation1)

    # Creates interpolated profiles.
    subDivRes = 50
    subDivSection0 = Pynet.GeoUtils.DivideByCount_GetPoints(Section0, subDivRes)
    subDivSection1 = Pynet.GeoUtils.DivideByCount_GetPoints(Section1, subDivRes)
    LinesForInterpolation = []
    for i in range(len(subDivSection0)):
        LinesForInterpolation.append(rg.Line(subDivSection0[i], subDivSection1[i]).ToNurbsCurve())
    PointsForInterpolation = []
    for i in range(len(LinesForInterpolation)):
        a = []
        for j in range(len(remapSeries)):
            a.append(LinesForInterpolation[i].PointAtNormalizedLength(remapSeries[j]))
        PointsForInterpolation.append(a)
    PointsForInterpolation_flipMatrix = map(list, zip(*PointsForInterpolation))

    InterpolatedCurves = []
    for i in range(len(PointsForInterpolation_flipMatrix)):
        InterpolatedCurves.append(rg.NurbsCurve.Create(boolPeriodic,3,PointsForInterpolation_flipMatrix[i]))

    # Projects the curve profiles back to the generated perpendicular frames.
    ProfilesSweep = []
    for i in range(len(InterpolatedCurves)):
        BackToLocalCoordinates = rg.Transform.PlaneToPlane(rg.Plane.WorldXY, PerpFrames[i])
        CurvesToMap = InterpolatedCurves[i]
        CurvesToMap.Transform(BackToLocalCoordinates)
        ProfilesSweep.append(CurvesToMap)

    # Geometry Generation
    if GeometryGeneration == 0: # Generates Quad-Mesh.
        PointsOnProfiles = []
        for i in range(len(ProfilesSweep)):
            DivPoints = Pynet.GeoUtils.DivideByCount_GetPoints(ProfilesSweep[i],Subdivision_V)
            PointsOnProfiles.append(DivPoints)
    
        if boolPeriodic == True:
            MeshSweep = rg.Mesh()
            for i in range(len(PointsOnProfiles)-1):
                for j in range(len(PointsOnProfiles[i])):
                    MeshSweep.Vertices.Add(PointsOnProfiles[i][j-1])
                    MeshSweep.Vertices.Add(PointsOnProfiles[i][j])
                    MeshSweep.Vertices.Add(PointsOnProfiles[i+1][j])
                    MeshSweep.Vertices.Add(PointsOnProfiles[i+1][j-1])
            MeshSweepVertices = MeshSweep.Vertices.ToPoint3dArray()
        else:
            MeshSweep = rg.Mesh()
            for i in range(len(PointsOnProfiles)-1):
                for j in range(len(PointsOnProfiles[i])-1):
                    MeshSweep.Vertices.Add(PointsOnProfiles[i][j])
                    MeshSweep.Vertices.Add(PointsOnProfiles[i][j+1])
                    MeshSweep.Vertices.Add(PointsOnProfiles[i+1][j+1])
                    MeshSweep.Vertices.Add(PointsOnProfiles[i+1][j])
            MeshSweepVertices = MeshSweep.Vertices.ToPoint3dArray()
        
        for i in range(len(MeshSweepVertices)):
            if i%4 == 0:
                MeshSweep.Faces.AddFace(i, i+1, i+2, i+3)
        MeshSweep.Normals.ComputeNormals()
        MeshSweep.Compact()
        return MeshSweep
    elif GeometryGeneration == 1: # Generates Surface (Loft).
        SurfaceSweep = rg.Brep.CreateFromLoft(ProfilesSweep, rg.Point3d.Unset, rg.Point3d.Unset, rg.LoftType.Normal, False)
        return SurfaceSweep
    elif GeometryGeneration == 2: # Do nothing.
        return ProfilesSweep

def Scale_Linelike_Curve(Linelike_Curve,fact):
    # Scale a Linelike_Curve
    stPtToMove = deepcopy(Linelike_Curve.PointAtStart)
    Vec = rg.Point3d.Subtract(Linelike_Curve.PointAtEnd, Linelike_Curve.PointAtStart)
    Vec.Unitize()
    ScaleTrans = rg.Transform.Translation(rg.Vector3d.Multiply(fact, Vec))
    stPtToMove.Transform(ScaleTrans)
    return rg.Line(Linelike_Curve.PointAtStart, stPtToMove)

def RectanglesFromPlanesOrigins(ListPlanes, RectangleThickness, FilletBool, fillet):
    from ghpythonlib import components as ghcomp
    Rectangles = []
    for i in range(len(ListPlanes)):
        Interval = rg.Interval(-RectangleThickness, RectangleThickness)
        Rectangle = rg.Rectangle3d(ListPlanes[i], Interval, Interval).ToNurbsCurve()
        if FilletBool == True:
            Rectangle = ghcomp.FilletDistance(Rectangle, fillet).ToNurbsCurve()
        else:
            pass
        Rectangle.Domain = rg.Interval(0,1)
        Rectangles.append(Rectangle)
    return Rectangles