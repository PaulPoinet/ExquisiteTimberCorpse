""" 
Utility graph management functions for writing GHPython scripts
Author: Paul Poinet
"""

import Rhino.Geometry as rg
import networkx as nx
import copy
import Pynet
from networkx import Graph, find_cliques
from itertools import combinations, takewhile

def pointsToNXNodes(Pts, Graph):
    """ Adds nodes into a Graph from an ordered point list """
    Nodes = [] 
    NodesIndices = []
    for i in range(len(Pts)):
        Graph.add_node(i, point=Pts[i])
        Nodes.append(nx.get_node_attributes(Graph,'point').values()[i])
        NodesIndices.append(Graph.nodes()[i])
    return Nodes, NodesIndices
    
def curvesToNXEdges(Curves, EdgesIndices, Graph):
    """ Adds edges into a Graph from an ordered curve list and respective edge indices """
    for i in range(len(Curves)):
        Graph.add_edge(EdgesIndices[i][0], EdgesIndices[i][1], line=Curves[i])


def findAllCyclesInGraph(Graph):
    """ Returns all the cycles present within a Graph """
    CyclesFromAllRoots = []
    for i in range(len(Graph.nodes())):
        CyclesFromAllRoots.append(nx.cycle_basis(Graph,i)) # Get all cycles in Graph from all roots
    CyclesFromAllRoots = Pynet.ListUtils.flattenNestedList(CyclesFromAllRoots)
    CyclesFromAllRoots_Copy = copy.deepcopy(CyclesFromAllRoots) 
    for L in CyclesFromAllRoots: #sort list
        L.sort()
    DuplicatedIndices = Pynet.ListUtils.findDupSublistsInNestedList(CyclesFromAllRoots)[1]
    Cycles = [] #get original sublists from original copy
    for i in DuplicatedIndices:
        Cycles.append(CyclesFromAllRoots_Copy[i])
    #CyclesTree = ListUtils.pythonListTGhDataTree(Cycles, int)
    return Cycles

def getCyclesGeometry(Cycles, Graph):
    """ Returns the geometrical information from a list of cycles within a graph """
    CyclesNodes = []
    for i in range(len(Cycles)):
        a = []
        for j in range(len(Cycles[i])):
            a.append(nx.get_node_attributes(Graph,'point').values()[Cycles[i][j]])
        CyclesNodes.append(a)
    
    CyclesCurves = []
    for i in range(len(CyclesNodes)):
        CyclesNodes[i].append(CyclesNodes[i][0])
        CyclesCurves.append(rg.Polyline(CyclesNodes[i]))
    return CyclesNodes, CyclesCurves

def CyclesTopologyEdges(Cycles, CyclesCurves, Graph):
    
    """ Analyses the edge topology of a curve network consisting of closed cycles. """

    # Get unique list of segments.
    CyclesCurvesSegments = []
    for i in range(len(CyclesCurves)):
        CyclesCurvesSegments.append(CyclesCurves[i].GetSegments())
    CyclesCurvesSegments = Pynet.ListUtils.flattenNestedList(CyclesCurvesSegments)
    CyclesCurvesSegments = Pynet.GeoUtils.removeDuplicateLines(CyclesCurvesSegments, 0.01)
    
    # Get PointCloud for each Cycle.
    CyclesNodes = Pynet.GraphUtils.getCyclesGeometry(Cycles, Graph)[0]
    PointCloudCycles = []
    for i in range(len(CyclesNodes)):
        PointCloudCycles.append(rg.PointCloud(CyclesNodes[i]))
    
    # Get both start and end points of each line.
    stPtOnLine = []  
    enPtOnLine = []
    for i in range(len(CyclesCurvesSegments)):
        stPtOnLine.append(CyclesCurvesSegments[i].PointAt(0.0))
        enPtOnLine.append(CyclesCurvesSegments[i].PointAt(1.0))
        
    # For each edge lists adjacent polyline indices.
    CyclesIndices = []
    for i in range(len(stPtOnLine)):
        a = []
        for j in range(len(PointCloudCycles)):
            DisStPtOnLine = round(rg.Point3d.DistanceTo(PointCloudCycles[j].GetPoints()[PointCloudCycles[j].ClosestPoint(stPtOnLine[i])], stPtOnLine[i]),3)
            DisEnPtOnLine = round(rg.Point3d.DistanceTo(PointCloudCycles[j].GetPoints()[PointCloudCycles[j].ClosestPoint(enPtOnLine[i])], enPtOnLine[i]),3)
            if DisStPtOnLine < 0.01 and DisEnPtOnLine < 0.01:
                a.append(j)
        CyclesIndices.append(a)
        
    #CycleIndices = Pynet.ListUtils.pythonListTGhDataTree(CycleIndices, int)
    
    return CyclesCurvesSegments, CyclesIndices

def getIndexNakedSingleNodeAndNeighbor(nx_Graph):

    """ Returns IndexNakedSingleNode and IndexNakedSingleNodeNeighbor """

    # Appends neighbors at each node
    IndexNodesNeighbors = []
    for i in range(len(nx_Graph.nodes())):
        IndexNodesNeighbors.append(nx_Graph.neighbors(i))

    # Checks if node is naked and single, retrieve index and neighbor index
    IndexNakedSingleNode = []
    IndexNakedSingleNodeNeighbor = []
    for i in range(len(IndexNodesNeighbors)):
        if len(IndexNodesNeighbors[i]) == 1:
            IndexNakedSingleNode.append(i)
            IndexNakedSingleNodeNeighbor.append(IndexNodesNeighbors[i])
        else:
            pass
    IndexNakedSingleNodeNeighbor = Pynet.ListUtils.flattenNestedList(IndexNakedSingleNodeNeighbor)
    return IndexNakedSingleNode, IndexNakedSingleNodeNeighbor

def getNonOverlappingKCliques(NestedCliques):
    
    """ Find the largest nested list of non-intersecting sets from an original nested list. """
    
    NestedCliques = map(tuple, NestedCliques) # Converts to tuple
    
    gr = Graph()
    gr.add_nodes_from(NestedCliques)
    
    for sublist1, sublist2 in combinations(NestedCliques, 2):
        if set(sublist1).isdisjoint(sublist2):
            gr.add_edge(sublist1, sublist2)
    SortedFlat = []
    lenSortedFlat = []
    SortedClique = []
    cliques = sorted(find_cliques(gr), key=len, reverse=True)
    cliques = list(takewhile(lambda NestedCliques: len(NestedCliques) == len(cliques[0]), cliques))
    
    for clique in cliques:
        flat = sum(clique, ())
        assert len(flat) == len(set(flat))
        SortedFlat.append(sorted(flat))
        lenSortedFlat.append(len(sorted(flat)))
        SortedClique.append((sorted(clique)))
    
    Index = max(xrange(len(lenSortedFlat)), key = lambda x: lenSortedFlat[x])
    largestCliques = SortedClique[Index]
    largestCliques = map(list, largestCliques) # Converts to nested list

    return largestCliques

def Graph2PtCloud(Graph):
    GraphPtCloud = rg.PointCloud(nx.get_node_attributes(Graph, 'point').values())
    return GraphPtCloud