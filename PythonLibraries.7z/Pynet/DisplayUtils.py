"""
Utility display management functions for writing GHPython scripts
Author: Anders Holden Deleuran
"""

def customDisplay(toggle,component):
    """ Make a custom display which is unique to the component and lives in sticky. """
    import Rhino
    from scriptcontext import sticky as st
    # Make unique name and custom display
    displayGuid = "customDisplay_" + str(component.InstanceGuid)
    if displayGuid not in st:
        st[displayGuid] = Rhino.Display.CustomDisplay(True)
    # Clear display each time component runs
    st[displayGuid].Clear()
    # Return the display or get rid of it
    if toggle:
        return st[displayGuid]
    else:
        st[displayGuid].Dispose()
        del st[displayGuid]
        return None

def killCustomDisplays():
    import Rhino
    from scriptcontext import sticky as st
    """ Clear any custom displays living in the Python sticky dictionary. """
    for k,v in st.items():
        if type(v) is Rhino.Display.CustomDisplay:
            v.Dispose()
            del st[k]