"""
Utility dictionary management functions for writing GHPython scripts
Author: Paul Poinet
"""


def ClusterDict(dict):

    """ Clustering the keys of a dict according to its values. """

    from collections import defaultdict
    clusters = defaultdict(list)
    for key, val in dict.iteritems():
        clusters[val].append(key)

    return clusters