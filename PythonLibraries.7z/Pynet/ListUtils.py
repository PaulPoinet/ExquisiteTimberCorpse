"""
Utility list management functions for writing GHPython scripts
Author: Paul Poinet
"""

import Pynet
from itertools import groupby


def ghDataTreeToPythonList(dataTree):
    """ Converts a GH datatree to a nested Python list. """
    pyList = []
    for i in range(dataTree.BranchCount):
        branch = list(dataTree.Branch(i))
        pyList.append(branch)
    return pyList


def pythonListTGhDataTree(pythonList, listType):
    """ Converts a nested Python list to a GH datatree. """
    import Grasshopper as gh
    # Create GH datatree
    dataTree = gh.DataTree[listType]()
    # Add pythonlist sub lists to dataTree
    for i,l in enumerate(pythonList):
        for v in l:
            dataTree.Add(v,gh.Kernel.Data.GH_Path(i))
    return dataTree


def splitByLengths(sequence, lengths, remainder=True):
    """ Splits a list into a custom number of different lengths. """
    last, SequenceLength = 0, len(sequence)
    for length in lengths:
        if last >= SequenceLength: return  # avoid empty lists
        adjacent = last + length
        yield sequence[last:adjacent]
        last = adjacent
    if last < SequenceLength and remainder:
        yield sequence[last:]


def chunksList(l, n):
    """ Returns an n-sized chunked nested list. """
    chunkedList = []
    for i in range(0, len(l), n):
        chunkedList.append(l[i:i+n])
    return chunkedList


def flattenNestedList(NestedList):
    """ Flattens a nested list from one level. """
    return [item for sublist in NestedList for item in sublist]


def findDupSublistsInNestedList(NestedList):
    """ Finds duplicated sublists from a nested list. """
    out = []
    index = []
    seen = set()
    for i in range(len(NestedList)):
        tp = tuple(NestedList[i])
        if tp not in seen:
            out.append(NestedList[i])
            index.append(i)
        seen.add(tp)
    return out, index


def findLargestSublistinNestedList(NestedList):
    """ Find the largest sublist from a nested list. Returns the sublist and its respective key index. """
    return max(enumerate(NestedList), key = lambda tup: len(tup[1]))


def sortListWithKeys(KeysList, ValuesList):
    """ Sorts a list with keys. """
    return [x for (y,x) in sorted(zip(KeysList,ValuesList))]


def sortValuesAndKeys(Keys, Values):
    """ Sorts a list of values and/with a list of keys. """
    return zip(*sorted(zip(Keys, Values)))


def sortListKeysWithListValues(Keys,Values):
    sortedIndices = sorted(range(len(Values)),key=lambda x:Keys[x])
    sortedKeys = [Keys[i] for i in sortedIndices]
    sortedValues = [Values[i] for i in sortedIndices]
    return sortedKeys, sortedValues, sortedIndices 


def SortAndGroupValuesWithKeys(Keys, Values):
    # sorts everything
    sortedKeys = Pynet.ListUtils.sortListKeysWithListValues(Keys, Values)[0]
    sortedValues = Pynet.ListUtils.sortListKeysWithListValues(Keys, Values)[1]
    sortedIndices = Pynet.ListUtils.sortListKeysWithListValues(Keys, Values)[2]
    # creates dict
    Dict = []
    for i in range(len(sortedValues)):
        Dict.append((sortedValues[i],sortedKeys[i]))
    # group dict
    groupKeys = []
    groupValues = []
    for key,valuesiter in groupby(Dict, key=lambda s:s[1]):
        groupKeys.append(key)
        groupValues.append(list(v[0] for v in valuesiter))
    return groupValues, sortedIndices


def list_to_tree(input, none_and_holes=True, source=[0]):
    """ Transforms nestings of lists or tuples to a Grasshopper DataTree. """
    from Grasshopper import DataTree as Tree
    from Grasshopper.Kernel.Data import GH_Path as Path
    from System import Array
    def proc(input,tree,track):
        path = Path(Array[int](track))
        if len(input) == 0 and none_and_holes: tree.EnsurePath(path); return
        for i,item in enumerate(input):
            if hasattr(item, '__iter__'): #if list or tuple
                track.append(i); proc(item,tree,track); track.pop()
            else:
                if none_and_holes: tree.Insert(item,path,i)
                elif item is not None: tree.Add(item,path)
    if input is not None: t=Tree[object]();proc(input,t,source[:]);return t


def tree_to_list(input, retrieve_base = lambda x: x[0]):
    """ Returns a list representation of a Grasshopper DataTree. """
    def extend_at(path, index, simple_input, rest_list):
        target = path[index]
        if len(rest_list) <= target: rest_list.extend([None]*(target-len(rest_list)+1))
        if index == path.Length - 1:
            rest_list[target] = list(simple_input)
        else:
            if rest_list[target] is None: rest_list[target] = []
            extend_at(path, index+1, simple_input, rest_list[target])
    all = []
    for i in range(input.BranchCount):
        path = input.Path(i)
        extend_at(path, 0, input.Branch(path), all)
    return retrieve_base(all)